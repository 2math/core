package com.futurist_labs.android.base_library.views.font_views;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.support.v4.util.ArrayMap;
import android.util.AttributeSet;
import android.widget.TextView;

import com.futurist_labs.android.base_library.model.BaseLibraryConfiguration;


/**
 * Created by Galeen on 9.5.2016 г..
 * Custom TextView to easy set fonts
 */
public class FontHelper {
    public static final String FONT_ASSETS = "file:///android_asset/";

    private static String boldFont = "fonts/Comfortaa-Bold.ttf";
    private String regularFont = BaseLibraryConfiguration.getInstance().getRegularFont();
    private static String italicFont = "fonts/FuturaLT.ttf";
    private static String lightFont = "fonts/Comfortaa-Light.ttf";
    private static String awesome = "fonts/fa-solid-900.ttf";
    public static final int BOLD = 1;
    public static final int NORMAL = 0;
    public static final int ITALIC = 2;
    public static final int LIGHT = 3;
    public static final int AWESOME = 4;
    private static ArrayMap<String, Typeface> fontCache = new ArrayMap<>();
    private FontType type = FontType.REGULAR;
    private TextView view;

    public static Typeface getTypeface(String fontName, Context context) {
        Typeface typeface = fontCache.get(fontName);

        if (typeface == null) {
            try {
                typeface = Typeface.createFromAsset(context.getAssets(), fontName);
            } catch (Exception e) {
                return null;
            }

            fontCache.put(fontName, typeface);
        }

        return typeface;
    }

    public static String setCustomFontForWebView(String htmlString, String path, float textSize, String color, String
            linkColorHex) {
        if (linkColorHex != null) {
            linkColorHex = String.format("a{color: %s}", linkColorHex);
        } else {
            linkColorHex = "";
        }
        return "<html>" +
                "<head>" +
                "<style type=\"text/css\">" +
                "@font-face {" +
                "font-family: MyFont;" +
                "src: url(\"" + path + "\")" +
                "}" +
                "body {" +
                "font-family: MyFont;" +
                "font-size: " + textSize + "px;" +
//                "text-align: justify;" +
                "color: " + color + ";" +
                "}" +
                "img{display: inline;height: auto;max-width: 100%;}" +
                linkColorHex +
                "</style>" +
                "</head>" +
                "<body>" + htmlString +
                "</body>" +
                "</html>";
    }

    public static String setCustomFontForWebView(String htmlString, int type, float textSize, String color, String
            linkColorHex) {
        if (color == null) color = "#989898";
        String font = FONT_ASSETS;
        switch (type) {
            case BOLD:
                font += boldFont;
//                view.setTypeface(getTypeface(boldFont, view.getContext()), Typeface.BOLD);
                break;
            case ITALIC:
                font += italicFont;
                break;
            case LIGHT:
                font += lightFont;
                break;
            case AWESOME:
                font += awesome;
                break;
            default:
                font += "fonts/System_San_Francisco_Display_Regular.ttf";
                break;
        }
        return setCustomFontForWebView(htmlString, font, textSize, color, linkColorHex);
    }

    public static String getItalicFont() {
        return italicFont;
    }

    public static String getLightFont() {
        return lightFont;
    }

    public static String getAwesome() {
        return awesome;
    }

    public static void init(String bold, String italic, String light) {
        boldFont = bold;
        italicFont = italic;
        lightFont = light;
    }

    public static void setAwesome(String font) {
        awesome = font;
    }

    private StyleAttributes attr;

    FontHelper(TextView view, StyleAttributes attr) {
        this.view = view;
        this.attr = attr;
    }

    void init(Context context, AttributeSet attrs) {
        if (attrs != null) {
            TypedArray a = context.getTheme().obtainStyledAttributes(
                    attrs, attr.getAttr(), 0, 0);
            try {

                if (a.getString(attr.getTvFont()) != null) {
                    String fontName = a.getString(attr.getTvFont());
                    regularFont = "fonts/" + fontName;
                    //setTypeface(getTypeface(regularFont, context));//Typeface.createFromAsset(getParentActivity().getAssets(), regularFont));
                } else {
                    if (a.getInt(attr.getTvType(), -1) != -1)
                        type = FontType.fromType(a.getInt(attr.getTvType(), 0));
                }
                setViewFont(type);
            } finally {
                a.recycle();
            }
        }
//        if (view.getTextSize() == view.getContext().getResources().getDimensionPixelSize(R.dimen.sp14)) {
//            view.setTextSize(view.getContext().getResources().getDimensionPixelSize(R.dimen.text_normal));
//        }
    }


    public void setViewFont(FontType type) {
        if (view == null) return;
        switch (type) {
            case BOLD:
                if(view.getTypeface().isBold()){
                    view.setTypeface(getTypeface(boldFont, view.getContext()), Typeface.BOLD);
                }else{
                    view.setTypeface(getTypeface(boldFont, view.getContext()));
                }
                break;
            case ITALIC:
                if(view.getTypeface().isItalic()){
                    view.setTypeface(getTypeface(boldFont, view.getContext()), Typeface.ITALIC);
                }else{
                    view.setTypeface(getTypeface(italicFont, view.getContext()));
                }
                break;
            case LIGHT:
                view.setTypeface(getTypeface(lightFont, view.getContext()));
                break;
            case AWESOME:
                view.setTypeface(getTypeface(awesome, view.getContext()));
                break;
            default:
                view.setTypeface(getTypeface(regularFont, view.getContext()));
                break;
        }
    }

    public void setViewFont(boolean goBold) {
        if (view == null) return;
//        if (goBold)
//            setTypeface(null, Typeface.BOLD);
//        else
//            setTypeface(null, Typeface.NORMAL);

        if (goBold)
            setViewFont(FontType.BOLD);
        else
            setViewFont(FontType.REGULAR);
    }

    public static String getBoldFont() {
        return boldFont;
    }

    public String getRegularFont() {
        return regularFont;
    }

    public void setRegularFont(String regularFont) {
        this.regularFont = regularFont;
    }

    public enum FontType {
        REGULAR(0),
        BOLD(1),
        ITALIC(2),
        LIGHT(3),
        AWESOME(4);


        int type;

        FontType(int type) {
            this.type = type;
        }

        static FontHelper.FontType fromType(int type) {
            for (FontHelper.FontType drf : values()) {
                if (drf.type == type) return drf;
            }
            throw new IllegalArgumentException();
        }
    }

    public static class StyleAttributes {
        private int[] attr;
        private int tvFont, tvType;

        public StyleAttributes(int[] attr, int tvFont, int tvType) {
            this.attr = attr;
            this.tvFont = tvFont;
            this.tvType = tvType;
        }

        public int[] getAttr() {
            return attr;
        }

        public int getTvFont() {
            return tvFont;
        }

        public int getTvType() {
            return tvType;
        }
    }
}
